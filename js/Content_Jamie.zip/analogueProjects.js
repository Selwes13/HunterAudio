//to display multiple images, just seperate them with a comma
//one image: image: "image1.png"
//two images: image: "image1.png, image2.png"
var projects = [
    {
        title:"Project 1",
        image:"../rb.png",
        text:"Hello, this is my lastest project",
        date:"Jan 2018"
    },
    {
        title:"Project 2",
        image:"../rb.png, ../rb.png, ../rb.png",
        text:"Hello, this is my second lastest project",
        date:"dec 2017"
    },
    {
        title:"Project 3",
        image:"../rb.png",
        text:"Hello, this is a later project where I made some stuff",
        date:"oct 2017"
    }
];