
var testimonials = [
    { 
        text: "He's a good 'un",
        name: "Sam Elwes"
    }, 
    { 
        text: "Good with the music and such",
        name: "Sam Elwes"
    }, 
    { 
        text: "What a musical man",
        name: "Sam Elwes"
    }
];